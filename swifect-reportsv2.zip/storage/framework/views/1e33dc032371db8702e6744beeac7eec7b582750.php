<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

	<title>Mutasi Bahan Baku Dokumen</title>
</head>
<body class="idr" onload="window.print()">

<div style="margin-left: 0%; margin-right: 0%;">
<h5>LAPORAN PERTANGGUNG JAWABAN MUTASI BAHAN BAKU <br>

<?php
    if ($datefrForm == NULL AND $datetoForm == NULL) {
    }else{
?>
PERIODE <?php echo e($datefrForm); ?> S.D <?php echo e($datetoForm); ?></h5>
<?php } ?>
<center>
<table id="mytable" border="1px" cellspacing="0">
       <tr>
                            <td align="center">No</td>
                            <td align="center">Kode Barang</td>
                            <td align="center">Nama Barang</td>
                            <td align="center">Satuan</td>
                            <td align="center">Saldo Awal</td>
                            <td align="center">Pemasukkan</td>
                            <td align="center">Pengeluaran</td>
                            <td align="center">Penyesuaian (Adjustment)</td>
                            <td align="center">Stock Akhir</td>
                            <td align="center">Stock Opname</td>
                            <td align="center">Selisih</td>
                            <td align="center">Keterangan</td>
                        </tr>      
                        <?php
                            $no = 0;
                        ?>
                        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php
                            $no++;
                            ?>
                                    <td><div style="word-wrap: break-word;" ><?php echo e($no); ?></div></td>
                                    <td><div style="word-wrap: break-word;" ><?php echo e($item->code_mitem); ?></div></td>
                                    <td><div style="word-wrap: break-word;" ><?php echo e($item->name_mitem); ?></div></td>
                                    <td><div style="word-wrap: break-word;" ><?php echo e($item->satuan); ?></div></td>
                                    <td><div style="width: 60px; word-wrap: break-word; " ><?php echo e(number_format($item->stock_awal, 2, '.', ',')); ?></div></td>
                                    <td><div style="width: 60px; word-wrap: break-word; " ><?php echo e(number_format($item->stock_in, 2, '.', ',')); ?></div></td>
                                    <td><div style="width: 60px; word-wrap: break-word; " ><?php echo e(number_format($item->stock_out, 2, '.', ',')); ?></div></td>
                                    <td><div style="word-wrap: break-word;" >0</div></td>
                                    <td><div style="width: 60px; word-wrap: break-word; " ><?php echo e(number_format($item->stock_akhir, 2, '.', ',')); ?></div></td>
                                    <td><div style="word-wrap: break-word;" >--</div></td>
                                    <?php if($item->stock_opname == 0): ?>
                                    <td><div style="word-wrap: break-word;" >--</div></td>
                                    <?php else: ?>
                                    <td><div style="word-wrap: break-word;" ><?php echo e(number_format($item->stock_opname, 2, '.', ',')); ?></div></td>
                                    <?php endif; ?>
                                    <td><div style="word-wrap: break-word;" >Sesuai</div></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</center>
<br><br>
<p>
	<footer><a href="http://www.swifect.com">~ Swifect Custom Application ~</a></footer>
</div>
</body>
</html>

<style type="text/css" media="print">
  @page  { size: landscape; margin: 0px auto; }
</style>


<?php /**PATH D:\applications\swifect-laravel\resources\views/print/pdf/mutasibhnbaku_report.blade.php ENDPATH**/ ?>