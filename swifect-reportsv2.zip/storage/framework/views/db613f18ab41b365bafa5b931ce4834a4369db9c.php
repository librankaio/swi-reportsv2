<?php  
  $filename = "Mutasi_Scrap.xls";
  header("Content-Disposition: attachment; filename=\"$filename\"");
  header("Content-Type: application/vnd.ms-excel");
?>
<html>
<head>

    <title>Mutasi SCRAP</title>
</head>
<body class="idr" onload="window.print()">
<div style="margin-left: 0%; margin-right: 0%;">
<h5>LAPORAN PERTANGGUNG JAWABAN MUTASI SCRAP<br>
PT.<?php echo e($comp_name); ?><br>
<?php
    if ($datefrForm == NULL AND $datetoForm == NULL) {
    }else{
?>
PERIODE <?php echo e($datefrForm); ?> S.D <?php echo e($datetoForm); ?></h5>
<?php } ?>

<center>
<table id="mytable" border="1px" cellspacing="0">
       <tr>
            <td scope="col" class="border-bottom-0 border-end-0 border-2">No</td>
            <td scope="col" class="border-bottom-0 border-end-0 border-2">Kode Barang</td>
            <td align="center" class="border-bottom-0 border-end-0 border-2">Nama Barang</td>
            <td align="center" class="border-bottom-0 border-end-0 border-2">Satuan</td>
            <td scope="col" class="border-bottom-0 border-end-0 border-2">Saldo Awal</td>
            <td scope="col" class="border-bottom-0 border-end-0 border-2">Pemasukkan</td>
            <td scope="col" class="border-bottom-0 border-end-0 border-2">Pengeluaran</td>
            <td scope="col" class="border-bottom-0 border-end-0 border-2">Penyesuaian (Adjustment)</td>
            <td scope="col" class="border-bottom-0 border-2">Stock Akhir</td>
            <td align="center" class="border-bottom-0 border-end-0 border-2">Stock Opname</td>
            <td align="center" class="border-bottom-0 border-end-0 border-2">Selisih</td>
            <td align="center" class="border-bottom-0 border-2">Keterangan</td>
        </tr>
        
        <?php if(count($results) > 0): ?>
        <?php $no=0; ?>
        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
        <tr>
            <?php
            $no++;
            ?>
            <td scope="row" class="border-2"><?php echo e($no); ?></td>
            <td class="border-2"><?php echo e($item->code_mitem); ?></td>
            <td class="border-2"><?php echo e($item->name_mitem); ?></td>
            <td class="border-2"><?php echo e($item->satuan); ?></td>
            <?php if($item->stock_awal == 0): ?>
            <td class="border-2">--</td>
            <?php else: ?>
            <td class="border-2"><?php echo e(number_format($item->stock_awal, 2, '.', ',')); ?></td>
            <?php endif; ?>
            <?php if($item->stock_in == 0): ?>
            <td class="border-2">--</td>
            <?php else: ?>
            <td class="border-2"><?php echo e(number_format($item->stock_in, 2, '.', ',')); ?></td>
            <?php endif; ?>
            <?php if($item->stock_out == 0): ?>
            <td class="border-2">--</td>
            <?php else: ?>
            <td class="border-2"><?php echo e(number_format($item->stock_out, 2, '.', ',')); ?></td>
            <?php endif; ?>                       
            <td class="border-2">--</td>
            <?php if($item->stock_akhir == 0): ?>
            <td class="border-2">--</td>
            <?php else: ?>
            <td class="border-2"><?php echo e(number_format($item->stock_akhir, 2, '.', ',')); ?></td>
            <?php endif; ?>     
            <td class="border-2">--</td>
            <?php if($item->stock_opname == 0): ?>
            <td class="border-2">--</td>
            <?php else: ?>
            <td class="border-2"><?php echo e(number_format($item->stock_opname, 2, '.', ',')); ?></td>
            <?php endif; ?>
            <td class="border-2">Sesuai</td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php elseif(count($results) == 0): ?>
            <td colspan="13" class="border-2"> 
            <label for="noresult" class="form-label">NO DATA RESULTS...</label>
            </td>
        <?php endif; ?>
    </table>
</center>
<br><br>
<p>
    <footer><a href="http://www.swifect.com">~ Swifect Inventory BC ~</a></footer>
</div>
</body>
</html>

<style type="text/css" media="print">
  @page  { size: landscape; margin: 0px auto; }
</style>

<style type="text/css" media="print">
  @page  { margin: 0px auto; }
</style>
<?php /**PATH D:\applications\swifect-laravel\resources\views/print/excel/mutasiscrap_report.blade.php ENDPATH**/ ?>