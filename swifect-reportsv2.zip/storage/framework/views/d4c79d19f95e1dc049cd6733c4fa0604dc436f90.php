<?php  
  $filename = "Laporan_PemasukanDokumen.xls";
  header("Content-Disposition: attachment; filename=\"$filename\"");
  header("Content-Type: application/vnd.ms-excel");
?>
<html>
<head>

    <title>Pemasukan Dokumen</title>
    <style type="text/css">
        .text{
        mso-number-format:"\@";/*force text*/
        }

        .num {
        mso-number-format:General;
        }
    </style>
</head>
<body class="idr" onload="window.print()">
<div style="margin-left: 0%; margin-right: 0%;">
<h5>LAPORAN PERTANGGUNG JAWABAN PEMASUKAN DOKUMEN<br>

<?php echo e($comp_name); ?><br>
<?php
    if ($datefrForm == NULL AND $datetoForm == NULL) {
    }else{
?>
PERIODE <?php echo e($datefrForm); ?> S.D <?php echo e($datetoForm); ?></h5>
<?php } ?>

<center>
<table id="mytable" border="1px" cellspacing="0">
       <tr>
        <td align="center" rowspan="2">No</td>
        <td align="center" rowspan="2">Jenis Dokumen</td>
        <td align="center" colspan="2">Dokumen Pabean</td>
        <td align="center" colspan="2">Bukti Penerimaan Barang</td>
        <td align="center" rowspan="2">Supplier</td>
        <td align="center" rowspan="2">Kode Barang</td>
        <td align="center" rowspan="2">Nama Barang</td>
        <td align="center" rowspan="2">Satuan</td>
        <td align="center" rowspan="2">Jumlah</td>
        <td align="center" colspan="2" class="border-2">Nilai Barang</td>
        </tr>
        <tr>
            <td align="center" scope="col" class="border-top-0 border-bottom-0  border-2">Nomor Aju</td>
            <td align="center" scope="col" class="border-top-0 border-bottom-0  border-2">Tanggal</td>
            <td align="center" scope="col" class="border-top-0 border-bottom-0  border-2">Nomor Pendaftaran</td>
            <td align="center" scope="col" class="border-top-0 border-bottom-0  border-2">Tanggal</td>
            <td align="center" scope="col" class="border-top-0 border-bottom-0  border-2">Rupiah</td>
            <td align="center" scope="col" class="border-top-0 border-bottom-0  border-2">USD</td>
        </tr> 
        <?php if(count($results) > 0): ?>
        <?php $no=0; 
        $dpnomor = "" ?>
        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
        <tr>
            <?php if( $item->dpnomor == $dpnomor): ?>
                <td class="border-2"></td>
                <td class="border-2"></td>
                <td class="border-2"></td>
                <td class="border-2"></td>
                <td class="border-2"></td>
                <td class="border-2"></td>
                <td class="border-2"></td>
            <?php else: ?>
                <?php $no++ ?> 
                <td class="border-2"><?php echo e($no); ?></td>
                <td class="border-2"><?php echo e($item->jenis_dokumen); ?></td>
                <?php if(substr($item->dpnomor,0,1) == 0): ?>
                    <td class="border-2 num"><?php echo e("'".$item->dpnomor); ?></td>
                <?php else: ?>
                    <td class="border-2"><?php echo e($item->dpnomor); ?></td>
                <?php endif; ?> 
                <td class="border-2"><?php echo e(date("d/m/Y", strtotime($item->dptanggal))); ?></td>
                <td class="border-2"><?php echo e($item->bpbnomor); ?></td>
                <td class="border-2"><?php echo e(date("d/m/Y", strtotime($item->bpbtanggal))); ?></td>
                <td class="border-2"><?php echo e($item->pemasok_pengirim); ?></td>
            <?php endif; ?>
            <td class="border-2"><?php echo e($item->kode_barang); ?></td>
            <td class="border-2"><?php echo e($item->nama_barang); ?></td>
            <td class="border-2"><?php echo e($item->sat); ?></td>
            <?php if($item->jumlah == 0): ?>
            <td class="border-2">0</td>
            <?php else: ?>
            <td class="border-2"><?php echo e($item->jumlah); ?></td>
            <?php endif; ?>
            <?php if($item->nilai_barang == 0): ?>
            <td class="border-2">0</td>
            <?php else: ?>
            <td class="border-2"><?php echo e(number_format($item->nilai_barang, 2, '.', ',')); ?></td>
            <?php endif; ?>
            <?php if($item->nilai_barang_usd == 0): ?>
            <td class="border-2">0</td>
            <?php else: ?>
            <td class="border-2"><?php echo e(number_format($item->nilai_barang_usd, 2, '.', ',')); ?></td>
            <?php endif; ?>
        </tr>
        <?php 
        $dpnomor = $item->dpnomor
        ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php elseif(count($results) == 0): ?>
            <td colspan="13" class="border-2"> 
            <label for="noresult" class="form-label">NO DATA RESULTS...</label>
            </td>
        <?php endif; ?>
    </table>
</center>
<br><br>
<p>
    <footer><a href="http://www.swifect.com">~ Swifect Inventory BC ~</a></footer>
</div>
</body>
</html>

<style type="text/css" media="print">
  @page  { size: landscape; margin: 0px auto; }
</style>

<style type="text/css" media="print">
  @page  { margin: 0px auto; }
</style>
<?php /**PATH D:\applications\swifect-laravel\resources\views/print/excel/pemasukkan_report.blade.php ENDPATH**/ ?>