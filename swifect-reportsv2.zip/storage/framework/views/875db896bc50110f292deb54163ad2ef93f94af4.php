<input type="checkbox" id="check">
    
    
    <!-- Sidebar -->    
    <div class="sidebar" id="sidebar">
    
      <div class="head-sidebar">
      <a href="<?php echo e('pemasukan'); ?>" class="logo-btn"><img src="img/logo_pjt.png" alt="" class="logo color-light"><span>IT INVENTORY BC</span></img></a>
        <label for="check">
          <i class="fas fa-bars" id="sidebar_toggle"></i>
        </label>
      </div>      
      <center class="profile_form">
        
        <h4><?php echo e(session('comp_name')); ?></h4>
      </center>
      <a href="<?php echo e('pemasukan'); ?>" class="btn_Nav <?php echo e('pemasukan' == request()->path() ? 'btn_NavActive' : ''); ?>"><i class="fas fa-sign-in-alt"></i><span>Pemasukan Dokumen</span></a>
      <a href="<?php echo e('pengeluaran'); ?>" class="btn_Nav <?php echo e('pengeluaran' == request()->path() ? 'btn_NavActive' : ''); ?>"><i class="fas fa-sign-out-alt"></i><span>Pengeluaran Dokumen</span></a>
      <a href="<?php echo e('mutasibhnbaku'); ?>" class="btn_Nav <?php echo e('mutasibhnbaku' == request()->path() ? 'btn_NavActive' : ''); ?>"><i class="fa-regular fa-note-sticky"></i><span>Mutasi Bahan Baku</span></a>     
      <a href="<?php echo e('mutasibrgjadi'); ?>" class="btn_Nav <?php echo e('mutasibrgjadi' == request()->path() ? 'btn_NavActive' : ''); ?>"><i class="fa-regular fa-note-sticky"></i><span>Mutasi Barang Jadi</span></a>   
      <a href="<?php echo e('mutasiscrap'); ?>" class="btn_Nav <?php echo e('mutasiscrap' == request()->path() ? 'btn_NavActive' : ''); ?>"><i class="fa-regular fa-note-sticky"></i><span>Mutasi Scrap</span></a>      
      
      <a href="<?php echo e('mutasimesin'); ?>" class="btn_Nav <?php echo e('mutasimesin' == request()->path() ? 'btn_NavActive' : ''); ?>"><i class="fa-regular fa-note-sticky"></i></i><span>Mutasi Mesin</span></a>      
      <a href="<?php echo e('mutasiwip'); ?>" class="btn_Nav <?php echo e('mutasiwip' == request()->path() ? 'btn_NavActive' : ''); ?>"><i class="fa-regular fa-note-sticky"></i><span>Mutasi Working Process</span></a>      
      <a href="<?php echo e('mutasiloghist'); ?>" class="btn_Nav <?php echo e('mutasiloghist' == request()->path() ? 'btn_NavActive' : ''); ?>"><i class="fa-regular fa-note-sticky"></i><span>Mutasi Log History</span></a>      
      
    </div>
    <!-- END Sidebar --><?php /**PATH D:\applications\swifect-reportsv2\resources\views/partials/navbar.blade.php ENDPATH**/ ?>