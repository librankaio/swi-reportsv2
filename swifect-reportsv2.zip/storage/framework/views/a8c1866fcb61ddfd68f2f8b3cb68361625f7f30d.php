<input type="checkbox" id="check">
    
    
    <!-- Sidebar -->    
    <div class="sidebar" id="sidebar">
    
      <div class="head-sidebar">
      <a href="<?php echo e('pemasukan'); ?>" class="logo-btn"><img src="img/Logo_swi.png" alt="" class="logo color-light"><span>SWIFECT | ERP APPS</span></img></a>
        <label for="check">
          <i class="fas fa-bars" id="sidebar_toggle"></i>
        </label>
      </div>      
      <center class="profile_form">
        
        <h4>PT.ABC MANTAP</h4>
      </center>
      <a href="<?php echo e('pemasukan'); ?>" class="btn_Nav <?php echo e('pemasukan' == request()->path() ? 'btn_NavActive' : ''); ?>"><i class="fas fa-sign-in-alt"></i><span>Pemasukan Dokumen</span></a>
      <a href="<?php echo e('pengeluaran'); ?>" class="btn_Nav <?php echo e('pengeluaran' == request()->path() ? 'btn_NavActive' : ''); ?>"><i class="fas fa-sign-out-alt"></i><span>Pengeluaran Dokumen</span></a>
      
    </div>
    <!-- END Sidebar --><?php /**PATH D:\applications\Deploy\swifect-laravel\resources\views/partials/navbar.blade.php ENDPATH**/ ?>